export default function CartePage() {
  return (
    <>
      <div className="pagehead">
        <div><div className="eyebrow">Développement</div><h1>Carte des stagiaires</h1>
          <p className="lead">Visualiser la répartition géographique des stagiaires pour le démarchage et les débouchés (vente de matériel, formations supplémentaires, recrutement).</p></div>
      </div>
      <div className="card">
        <div className="empty">
          <div className="big">🗺</div>
          <h3>Carte interactive — module à venir</h3>
          <p style={{ maxWidth: 520, margin: "8px auto 0" }}>
            La carte géolocalisera les stagiaires (à partir de leur ville / code postal) et permettra de filtrer
            par formation, statut (salarié / à son compte) et débouché potentiel. Prévu en Phase 2 (intégration
            d'une carte de France + géocodage), une fois l'authentification et les fiches stagiaires complètes en place.
          </p>
        </div>
      </div>
    </>
  );
}
