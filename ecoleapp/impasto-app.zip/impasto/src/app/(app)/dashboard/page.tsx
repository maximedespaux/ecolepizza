import { prisma } from "@/lib/db";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const organizationId = "org-ecole-pizza";
  const [org, nbStagiaires, nbFormations, nbSessions, nbPartenaires, sessions] = await Promise.all([
    prisma.organization.findUnique({ where: { id: organizationId } }),
    prisma.learner.count({ where: { organizationId } }),
    prisma.trainingProgram.count({ where: { organizationId } }),
    prisma.trainingSession.count({ where: { organizationId } }),
    prisma.partner.count({ where: { organizationId } }),
    prisma.trainingSession.findMany({
      where: { organizationId },
      include: { program: true, _count: { select: { enrollments: true } } },
      orderBy: { semaine: "asc" }, take: 5,
    }),
  ]);

  return (
    <>
      <div className="pagehead">
        <div>
          <div className="eyebrow">Secrétariat · {org?.sigle}</div>
          <h1>Bonjour, Maxime</h1>
          <p className="lead">{org?.raisonSociale} — SIRET {org?.siret} · NDA {org?.nda} · Qualiopi.</p>
        </div>
        <Link className="btn primary" href="/documents">⎙ Générer des documents</Link>
      </div>

      <div className="grid cols-4" style={{ marginBottom: 18 }}>
        <Kpi label="Stagiaires" val={nbStagiaires} href="/stagiaires" />
        <Kpi label="Formations" val={nbFormations} href="/formations" />
        <Kpi label="Sessions" val={nbSessions} href="/sessions" />
        <Kpi label="Partenaires" val={nbPartenaires} href="/partenaires" />
      </div>

      <div className="grid cols-2">
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
            <h3>Prochaines sessions</h3>
            <Link href="/sessions" style={{ color: "var(--ember1)", fontSize: 13 }}>Toutes →</Link>
          </div>
          {sessions.length === 0 ? <p className="lead">Aucune session planifiée.</p> : sessions.map((s) => (
            <div key={s.id} style={{ display: "flex", gap: 12, padding: "10px 0", borderBottom: "1px solid var(--border-soft)" }}>
              <div style={{ width: 46, textAlign: "center" }}>
                <div className="mono" style={{ fontSize: 11, color: "var(--dim)" }}>SEM</div>
                <div style={{ fontFamily: "var(--font-d)", fontSize: 20, fontWeight: 700, color: "var(--ember1)" }}>{s.semaine}</div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13.5, fontWeight: 600 }}>{s.program.titre}</div>
                <div style={{ fontSize: 12, color: "var(--muted)" }}>{s.annee} · {s._count.enrollments} stagiaire(s)</div>
              </div>
            </div>
          ))}
        </div>
        <div className="card">
          <h3 style={{ marginBottom: 12 }}>Accès rapides</h3>
          <div style={{ display: "grid", gap: 10 }}>
            {[
              ["/stagiaires", "☺ Ajouter un stagiaire"],
              ["/sessions", "▦ Créer une session"],
              ["/documents", "⎙ Générer un devis / contrat"],
              ["/partenaires", "🤝 Gérer les partenaires"],
              ["/suivi", "▤ Vérifier la conformité Qualiopi"],
            ].map(([href, label]) => (
              <Link key={href} href={href} className="btn ghost" style={{ justifyContent: "flex-start" }}>{label}</Link>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

function Kpi({ label, val, href }: { label: string; val: number; href: string }) {
  return (
    <Link href={href} className="kpi card hover" style={{ display: "block" }}>
      <div className="lbl">{label}</div>
      <div className="val tnum">{val}</div>
      <div className="sub">Voir →</div>
    </Link>
  );
}
