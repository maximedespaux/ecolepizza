import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function GET(_req: NextRequest) {
  const organizationId = "org-ecole-pizza";
  const data = await prisma.trainingProgram.findMany({
    where: { organizationId }, orderBy: { prix: "desc" },
  });
  return NextResponse.json({ data });
}
