import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";

const Patch = z.object({
  titre: z.string().min(1).optional(),
  prix: z.coerce.number().optional(),
  jours: z.coerce.number().int().optional(),
  heures: z.coerce.number().int().optional(),
  public: z.string().optional(),
  objectifs: z.string().optional(),
});

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  let body: unknown; try { body = await req.json(); } catch { return NextResponse.json({ error: "JSON invalide" }, { status: 400 }); }
  const parsed = Patch.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Validation échouée" }, { status: 422 });
  const program = await prisma.trainingProgram.update({ where: { id }, data: parsed.data });
  await prisma.auditLog.create({ data: { organizationId: program.organizationId, action: "program.update", entity: "TrainingProgram", entityId: id } });
  return NextResponse.json({ data: program });
}
