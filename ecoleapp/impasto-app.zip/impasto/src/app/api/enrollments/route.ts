import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function GET(_req: NextRequest) {
  const organizationId = "org-ecole-pizza";
  const data = await prisma.enrollment.findMany({
    where: { session: { organizationId } },
    include: {
      learner: true,
      session: { include: { program: true } },
      _count: { select: { documents: true } },
    },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ data });
}
