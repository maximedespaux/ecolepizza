"use client";
import { useEffect, useState, useCallback } from "react";
import { toast } from "@/lib/toast";

interface Formation {
  id: string; code: string; titre: string; prix: string; jours: number; heures: number;
  public?: string; objectifs?: string; hygiene: boolean; rsCode?: string | null;
}

export default function FormationsClient() {
  const [items, setItems] = useState<Formation[]>([]);
  const [loading, setLoading] = useState(true);
  const [edit, setEdit] = useState<Formation | null>(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const j = await fetch("/api/formations").then((r) => r.json());
    setItems(j.data ?? []); setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!edit) return;
    setSaving(true);
    const res = await fetch("/api/formations/" + edit.id, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titre: edit.titre, prix: edit.prix, jours: edit.jours, heures: edit.heures, public: edit.public, objectifs: edit.objectifs }),
    });
    setSaving(false);
    if (res.ok) { setEdit(null); toast("Formation mise à jour"); load(); } else toast("Erreur", "err");
  };
  const setE = (k: keyof Formation, v: string) => setEdit((f) => (f ? { ...f, [k]: v } : f));

  return (
    <>
      <div className="pagehead">
        <div><div className="eyebrow">Catalogue</div><h1>Formations</h1>
          <p className="lead">Les 9 programmes. Cliquez une carte pour modifier tarif, durée ou objectifs — ces données alimentent devis et contrats.</p></div>
      </div>

      {loading ? <div className="empty">Chargement…</div> : (
        <div className="grid cols-3">
          {items.map((f) => (
            <div key={f.id} className="card hover" onClick={() => setEdit(f)}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start" }}>
                <span className={"badge " + (f.rsCode ? "r" : "n")}>{f.rsCode ?? f.code}</span>
                <span style={{ fontFamily: "var(--font-d)", fontSize: 24, fontWeight: 600, color: "var(--ember1)" }}>{Number(f.prix).toLocaleString("fr-FR")} €</span>
              </div>
              <h3 style={{ fontSize: 16, margin: "12px 0 6px" }}>{f.titre}</h3>
              <div style={{ fontSize: 12.5, color: "var(--muted)", minHeight: 32 }}>{f.objectifs}</div>
              <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
                <span className="badge n">{f.jours} jours</span><span className="badge n">{f.heures} h</span>
                {f.hygiene && <span className="badge n">+ hygiène</span>}
                <span className="badge a" style={{ marginLeft: "auto" }}>✎ Modifier</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {edit && (
        <div className="overlay" onClick={(e) => { if (e.target === e.currentTarget) setEdit(null); }}>
          <div className="modal">
            <div className="mhead"><h3>Modifier la formation</h3><button className="x" onClick={() => setEdit(null)}>×</button></div>
            <div className="mbody">
              <div className="field"><label>Intitulé</label><input className="inp" value={edit.titre} onChange={(e) => setE("titre", e.target.value)} /></div>
              <div className="row3">
                <div className="field"><label>Tarif net (€)</label><input className="inp tnum" value={edit.prix} onChange={(e) => setE("prix", e.target.value)} /></div>
                <div className="field"><label>Jours</label><input className="inp tnum" value={String(edit.jours)} onChange={(e) => setE("jours", e.target.value)} /></div>
                <div className="field"><label>Heures</label><input className="inp tnum" value={String(edit.heures)} onChange={(e) => setE("heures", e.target.value)} /></div>
              </div>
              <div className="field"><label>Public</label><input className="inp" value={edit.public ?? ""} onChange={(e) => setE("public", e.target.value)} /></div>
              <div className="field"><label>Objectifs</label><textarea className="inp" rows={3} value={edit.objectifs ?? ""} onChange={(e) => setE("objectifs", e.target.value)} /></div>
            </div>
            <div className="mfoot">
              <button className="btn" onClick={() => setEdit(null)}>Annuler</button>
              <button className="btn primary" onClick={save} disabled={saving}>{saving ? "Enregistrement…" : "Enregistrer"}</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
