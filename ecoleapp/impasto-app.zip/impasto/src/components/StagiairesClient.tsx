"use client";
import { useEffect, useState, useCallback } from "react";
import { toast } from "@/lib/toast";

interface Learner {
  id: string; civilite?: string; nom: string; prenom?: string; email?: string;
  telephone?: string; ville?: string; financement: string; opco?: string;
  company?: { nom: string } | null;
}
const empty = { civilite: "Monsieur", nom: "", prenom: "", email: "", telephone: "", ville: "", financement: "PARTICULIER", opco: "" };
const initials = (s: string) => s.split(/\s+/).filter(Boolean).map((w) => w[0]).join("").slice(0, 2).toUpperCase();

export default function StagiairesClient() {
  const [learners, setLearners] = useState<Learner[]>([]);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({ ...empty });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const load = useCallback(async (query = "") => {
    setLoading(true);
    const res = await fetch("/api/stagiaires" + (query ? "?q=" + encodeURIComponent(query) : ""));
    const json = await res.json();
    setLearners(json.data ?? []); setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const t = setTimeout(() => load(q), 250); return () => clearTimeout(t); }, [q, load]);

  const openNew = () => { setEditId(null); setForm({ ...empty }); setErr(""); setModal(true); };
  const openEdit = (l: Learner) => {
    setEditId(l.id);
    setForm({ civilite: l.civilite ?? "Monsieur", nom: l.nom, prenom: l.prenom ?? "", email: l.email ?? "", telephone: l.telephone ?? "", ville: l.ville ?? "", financement: l.financement, opco: l.opco ?? "" });
    setErr(""); setModal(true);
  };

  const submit = async () => {
    setErr("");
    if (!form.nom.trim()) { setErr("Le nom est requis."); return; }
    setSaving(true);
    const url = editId ? "/api/stagiaires/" + editId : "/api/stagiaires";
    const res = await fetch(url, { method: editId ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    setSaving(false);
    if (!res.ok) { const j = await res.json().catch(() => ({})); setErr(j.error || "Erreur."); return; }
    setModal(false); toast(editId ? "Stagiaire mis à jour" : "Stagiaire créé"); load(q);
  };

  const del = async (l: Learner) => {
    if (!confirm(`Supprimer ${l.nom} ${l.prenom ?? ""} et son dossier ?`)) return;
    const res = await fetch("/api/stagiaires/" + l.id, { method: "DELETE" });
    if (res.ok) { toast("Stagiaire supprimé"); load(q); } else toast("Suppression impossible", "err");
  };

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <>
      <div className="pagehead">
        <div><div className="eyebrow">Secrétariat</div><h1>Stagiaires</h1>
          <p className="lead">Cliquez une ligne pour modifier la fiche. Création, édition et suppression en direct.</p></div>
        <button className="btn primary" onClick={openNew}>+ Nouveau stagiaire</button>
      </div>

      <div className="searchbar">
        <input className="inp" placeholder="⌕ Nom, ville…" value={q} onChange={(e) => setQ(e.target.value)} />
        <span className="hint">{learners.length} résultat(s)</span>
      </div>

      <div className="card" style={{ padding: 0, overflowX: "auto" }}>
        {loading ? <div className="empty">Chargement…</div>
          : learners.length === 0 ? <div className="empty"><div className="big">☺</div><h3>Aucun stagiaire</h3><p>Ajoutez votre premier stagiaire pour démarrer.</p></div>
          : (
            <table>
              <thead><tr><th>Stagiaire</th><th>Ville</th><th>Financement</th><th>Entreprise</th><th></th></tr></thead>
              <tbody>
                {learners.map((l) => (
                  <tr key={l.id} className="click" onClick={() => openEdit(l)}>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
                        <div className="avatar" style={{ width: 34, height: 34, borderRadius: 9, fontSize: 12 }}>{initials(l.nom + " " + (l.prenom ?? ""))}</div>
                        <div><b>{l.nom} {l.prenom}</b><div style={{ fontSize: 11.5, color: "var(--muted)" }}>{l.email ?? "—"}</div></div>
                      </div>
                    </td>
                    <td>{l.ville ?? "—"}</td>
                    <td><span className={"badge " + (l.financement === "PARTICULIER" ? "b" : "a")}>{l.financement === "PARTICULIER" ? "Particulier" : "Professionnel"}</span></td>
                    <td>{l.company?.nom ?? (l.opco ? "OPCO " + l.opco : "—")}</td>
                    <td><div className="actions">
                      <button className="iconbtn" title="Modifier" onClick={(e) => { e.stopPropagation(); openEdit(l); }}>✎</button>
                      <button className="iconbtn del" title="Supprimer" onClick={(e) => { e.stopPropagation(); del(l); }}>🗑</button>
                    </div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
      </div>

      {modal && (
        <div className="overlay" onClick={(e) => { if (e.target === e.currentTarget) setModal(false); }}>
          <div className="modal">
            <div className="mhead"><h3>{editId ? "Modifier le stagiaire" : "Nouveau stagiaire"}</h3><button className="x" onClick={() => setModal(false)}>×</button></div>
            <div className="mbody">
              {err && <div className="badge r" style={{ marginBottom: 12 }}>{err}</div>}
              <div className="row3">
                <div className="field"><label>Civilité</label><select className="inp" value={form.civilite} onChange={(e) => set("civilite", e.target.value)}><option>Madame</option><option>Monsieur</option></select></div>
                <div className="field"><label>Nom</label><input className="inp" value={form.nom} onChange={(e) => set("nom", e.target.value)} /></div>
                <div className="field"><label>Prénom</label><input className="inp" value={form.prenom} onChange={(e) => set("prenom", e.target.value)} /></div>
              </div>
              <div className="row3">
                <div className="field"><label>Email</label><input className="inp" value={form.email} onChange={(e) => set("email", e.target.value)} /></div>
                <div className="field"><label>Téléphone</label><input className="inp" value={form.telephone} onChange={(e) => set("telephone", e.target.value)} /></div>
                <div className="field"><label>Ville</label><input className="inp" value={form.ville} onChange={(e) => set("ville", e.target.value)} /></div>
              </div>
              <div className="row2">
                <div className="field"><label>Financement</label><select className="inp" value={form.financement} onChange={(e) => set("financement", e.target.value)}><option value="PARTICULIER">Particulier</option><option value="PROFESSIONNEL">Professionnel</option></select></div>
                <div className="field"><label>OPCO <span className="hint">si professionnel</span></label><input className="inp" value={form.opco} onChange={(e) => set("opco", e.target.value)} placeholder="AKTO, AGEFICE…" /></div>
              </div>
            </div>
            <div className="mfoot">
              {editId && <button className="btn danger" style={{ marginRight: "auto" }} onClick={() => { const t = learners.find((x) => x.id === editId); setModal(false); if (t) del(t); }}>Supprimer</button>}
              <button className="btn" onClick={() => setModal(false)}>Annuler</button>
              <button className="btn primary" onClick={submit} disabled={saving}>{saving ? "Enregistrement…" : "Enregistrer"}</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
