"use client";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import Toaster from "./Toaster";

const NAV = [
  { grp: "Pilotage", items: [{ href: "/dashboard", ic: "◧", label: "Tableau de bord" }] },
  {
    grp: "Secrétariat",
    items: [
      { href: "/stagiaires", ic: "☺", label: "Stagiaires" },
      { href: "/calendrier", ic: "🗓", label: "Calendrier" },
      { href: "/sessions", ic: "▦", label: "Sessions & planning" },
      { href: "/documents", ic: "⎙", label: "Génération de documents" },
      { href: "/suivi", ic: "▤", label: "Suivi Qualiopi" },
    ],
  },
  {
    grp: "Développement",
    items: [
      { href: "/formations", ic: "◍", label: "Formations" },
      { href: "/partenaires", ic: "🤝", label: "Partenaires" },
      { href: "/carte", ic: "🗺", label: "Carte des stagiaires" },
    ],
  },
  { grp: "Système", items: [{ href: "/reglages", ic: "⚙", label: "Organisme" }] },
];

const TITLES: Record<string, string> = {
  "/dashboard": "Tableau de bord", "/stagiaires": "Stagiaires", "/sessions": "Sessions & planning",
  "/documents": "Génération de documents", "/suivi": "Suivi Qualiopi", "/formations": "Formations",
  "/partenaires": "Partenaires", "/carte": "Carte des stagiaires", "/reglages": "Organisme",
};

export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [theme, setTheme] = useState("dark");

  useEffect(() => {
    const t = localStorage.getItem("impasto_theme") || "dark";
    setTheme(t);
    document.documentElement.setAttribute("data-theme", t);
  }, []);
  useEffect(() => setOpen(false), [pathname]);

  const toggleTheme = () => {
    const t = theme === "dark" ? "light" : "dark";
    setTheme(t);
    localStorage.setItem("impasto_theme", t);
    document.documentElement.setAttribute("data-theme", t);
  };

  const active = (href: string) => pathname === href || pathname.startsWith(href + "/");

  return (
    <div className="app">
      <aside className={"sidebar" + (open ? " open" : "")}>
        <div className="brand">
          <Image src="/brand/logo.png" alt="École Pizza" width={42} height={42} />
          <div><div className="name">Impasto</div><div className="sub">École Pizza · Despaux</div></div>
        </div>
        <nav className="menu">
          {NAV.map((g) => (
            <div key={g.grp}>
              <div className="grp">{g.grp}</div>
              {g.items.map((it) => (
                <Link key={it.href} href={it.href} className={active(it.href) ? "on" : ""}>
                  <span className="ic">{it.ic}</span> {it.label}
                </Link>
              ))}
            </div>
          ))}
        </nav>
        <div className="side-foot">
          <div className="avatar">M</div>
          <div><div className="who">Maxime Despaux</div><div className="role">Secrétariat · Admin</div></div>
        </div>
      </aside>

      <div className={"scrim" + (open ? " show" : "")} onClick={() => setOpen(false)} />

      <div className="main">
        <header className="topbar">
          <button className="menu-btn" onClick={() => setOpen(true)}>☰</button>
          <div className="crumbs">Impasto <span style={{ opacity: 0.4 }}>/</span> <b>{TITLES[pathname] ?? ""}</b></div>
          <div className="spacer" />
          <button className="icon-btn" onClick={toggleTheme} title="Thème">◐</button>
        </header>
        <main className="content">{children}</main>
      </div>
      <Toaster />
    </div>
  );
}
